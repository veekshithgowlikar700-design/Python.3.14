/* SnakeByte enrollment collector example.
 * Deploy as a Google Apps Script Web App and paste its /exec URL into USER_API_URL.
 * This example intentionally stores only the fields the app sends.
 * Add authentication/authorization and a privacy policy before production use.
 */
const SHEET_NAME = 'Enrollments';

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow(['receivedAt','userId','name','email','phone','enrolledAt','appVersion','platform']);
    }
    sheet.appendRow([
      new Date(), data.userId || '', data.name || '', data.email || '',
      data.phone || '', data.enrolledAt || '', data.appVersion || '', data.platform || ''
    ]);
    return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ok:false,error:String(err)})).setMimeType(ContentService.MimeType.JSON);
  }
}
