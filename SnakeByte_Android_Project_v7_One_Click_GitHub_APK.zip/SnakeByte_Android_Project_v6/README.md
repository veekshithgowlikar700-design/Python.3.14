# 🐍 SnakeByte 3D — Python Learning Quest v7

A lightweight Android Python-learning game with animated 3D-style visuals, Python motion graphics, learner enrollment, and a GitHub one-click APK build.

## 🚀 Build the APK on GitHub — one click

1. Create a new **GitHub repository**.
2. Upload **everything inside this project folder** to the repository root. Do not upload the ZIP itself inside another folder.
3. Commit/push to `main`.
4. Open **Actions** → **🚀 Build SnakeByte APK**.
5. Click **Run workflow** → **Run workflow**.
6. Wait for the green ✅ build to finish.
7. Open that workflow run and scroll to **Artifacts**.
8. Download **SnakeByte-3D-Python-Quest-v7-APK**.
9. Inside it is `SnakeByte-3D-Python-Quest-v7-debug.apk`.

The workflow also runs automatically whenever you push to `main` or `master`.

## 🎮 What's included

- 3D-style Python motion graphics
- Animated floating Python/code cubes
- Game-like learning interface
- 3D-styled SnakeByte launcher icon
- Real learner enrollment: name + email + optional phone
- Unique local learner ID and enrollment timestamp
- No fake/demo learner names are created by the app
- Admin panel for the current enrolled learner
- Enrollment JSON export from the Admin panel
- Python examples use **double quotes** for strings
- Python editor shortcut row does not insert single quotes
- Android WebView app, designed to stay lightweight

## 👥 Seeing every enrolled user

The APK can store the current enrollment locally. To collect enrollments centrally, configure your own HTTPS backend using `USER_API_URL` in:

`app/src/main/assets/index.html`

Example:

```js
const USER_API_URL = "https://your-own-https-endpoint.example/enroll";
```

A starter Google Apps Script collector is included at:

`backend/google-apps-script/Code.gs`

### Google Sheets starter setup

1. Create a Google Sheet.
2. Open **Extensions → Apps Script**.
3. Paste the code from `backend/google-apps-script/Code.gs`.
4. Deploy it as a Web app.
5. Copy the `/exec` URL.
6. Put that URL into `USER_API_URL`.
7. Commit the change to GitHub.
8. Run **Actions → 🚀 Build SnakeByte APK → Run workflow**.

For a public app, add proper authentication/rate limiting, collect only necessary data, and provide appropriate privacy/consent disclosures. Never put database admin credentials in the APK.

## 🧩 Project structure

- `app/src/main/assets/index.html` — game UI, course, animations and Python runner
- `app/src/main/java/com/snakebyte/app/MainActivity.java` — Android WebView host
- `app/src/main/res/drawable/ic_launcher_3d.png` — launcher icon
- `backend/google-apps-script/Code.gs` — optional enrollment collector
- `.github/workflows/build-apk.yml` — one-click/automatic GitHub APK build

## ⚠️ Important

This workflow creates a **debug APK**, which is the easiest APK to install for testing. For a Play Store release, create a properly signed release build with your own private keystore; never commit the keystore or passwords to GitHub.
